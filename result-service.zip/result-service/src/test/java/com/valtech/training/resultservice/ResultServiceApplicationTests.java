package com.valtech.training.resultservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResultServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
