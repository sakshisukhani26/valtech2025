package com.valtech.training.sprsecauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprSecAuth2Application {

	public static void main(String[] args) {
		SpringApplication.run(SprSecAuth2Application.class, args);
	}

}
