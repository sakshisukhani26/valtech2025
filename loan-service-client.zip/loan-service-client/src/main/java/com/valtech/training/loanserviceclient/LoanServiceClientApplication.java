package com.valtech.training.loanserviceclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanServiceClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanServiceClientApplication.class, args);
	}

}
