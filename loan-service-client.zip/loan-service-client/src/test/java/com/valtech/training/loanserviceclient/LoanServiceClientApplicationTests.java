package com.valtech.training.loanserviceclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanServiceClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
