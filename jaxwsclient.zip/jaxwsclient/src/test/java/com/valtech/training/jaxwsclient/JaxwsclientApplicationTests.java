package com.valtech.training.jaxwsclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaxwsclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
