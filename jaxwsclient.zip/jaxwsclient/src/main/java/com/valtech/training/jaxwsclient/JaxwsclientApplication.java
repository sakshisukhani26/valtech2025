package com.valtech.training.jaxwsclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaxwsclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(JaxwsclientApplication.class, args);
	}

}
