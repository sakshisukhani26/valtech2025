package com.valtech.training.restapis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapisApplicationTests {

	@Test
	void contextLoads() {
	}

}
